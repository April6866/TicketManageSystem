package com.example.ticketmanagesystem.entity;

import java.io.Serializable;

public class User implements Serializable {
    private  String account;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    private String password;
    private int type;
}
